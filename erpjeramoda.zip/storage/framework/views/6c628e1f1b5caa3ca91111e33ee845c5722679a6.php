<?php if($errors->any()): ?>
<div class="alert alert-danger"></alert>
<ul class="m-0">
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($error); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?><?php /**PATH C:\laragon\www\erpjeramoda\resources\views/auxiliares/error_formulario.blade.php ENDPATH**/ ?>