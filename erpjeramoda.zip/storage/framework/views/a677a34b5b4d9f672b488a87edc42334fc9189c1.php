<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
        <img src="<?php echo e(asset('assets/dist/img/logo.jpeg')); ?>" alt="Logo de Netway"
            class="brand-image img-circle elevation-3" style="opacity: .8; background-color: white">
        <span class="brand-text font-weight-light"><strong>HIMART</strong></span>
    </a>

    <?php echo $__env->make('admin.layout.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\laragon\www\erpjeramoda\resources\views/admin/layout/aside.blade.php ENDPATH**/ ?>