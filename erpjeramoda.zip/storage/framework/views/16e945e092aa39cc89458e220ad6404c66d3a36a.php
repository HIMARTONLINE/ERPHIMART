

<?php $__env->startSection('title'); ?>
<h1 class="m-0 text-dark">Productos</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
    <li class="breadcrumb-item active">Administración</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Listado de productos</h3>
                    <a href="#" class="btn btn-danger float-right ml-3">
                        <i class="fa fa-file-excel"></i> Exportar Inventario
                    </a>
                    <a href="<?php echo e(route('admin.productos.create')); ?>" class="btn btn-success float-right">
                        <i class="fa fa-plus"></i> Añadir Producto
                    </a>
                </div>
                <br>
                <!-- /.card-header -->
                <div class="card-body">
                    <form id="form-produ" class="mb-4" action="<?php echo e(route('filtro-productos')); ?>" method="GET">
                        <?php echo csrf_field(); ?>    
                        <div class="row">
                            <div class="col-md-2">
                                <label>Categoría:</label>
                                <select class="form-control" name="categoria" id="categoria">
                                    <option value="1" selected>Seleccionar...</option>
                                    <?php $categorias = [];?>
                                    <?php $__currentLoopData = $parametros['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php array_push($categorias, $val['category']);
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                                    <?php $__currentLoopData = array_unique($categorias); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label>De: (Stock)</label>
                                <select class="form-control" name="de_stock" id="stock">
                                    <option value="0" selected>Seleccionar...</option>
                                    <?php for($i=1; $i<=200; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label>A: (Stock)</label>
                                <select class="form-control" name="a_stock" id="stock">
                                    <option value="200" selected>Seleccionar...</option>
                                    <?php for($i=1; $i<=200; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label>De: (Precio)</label>
                                <select class="form-control" name="de_precio" id="de_precio">
                                    <option value="0.00" selected>Seleccionar...</option>
                                    <?php for($i=0; $i<=2000; $i+=20): ?>
                                    <option value="<?php echo e($i . '.00'); ?>"><?php echo e($i . '.00'); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label>A: (Precio)</label>
                                <select class="form-control" name="a_precio" id="a_precio">
                                    <option value="2000.00" selected>Seleccionar...</option>
                                    <?php for($i=0; $i<=2000; $i+=20): ?>
                                    <option value="<?php echo e($i . '.00'); ?>"><?php echo e($i . '.00'); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>De: (Fecha)</label>
                                <input class="form-control" type="date" name="de_fecha" value="2020-01-01">
                            </div>
                            <div class="col-md-2">
                                <label>A: (Fecha)</label>
                                <input class="form-control" type="date" name="a_fecha" value="<?php echo e(date('Y-m-d')); ?>">
                            </div>
                            <div class="col-md-2">
                                <input class="btn btn-info" style="margin-top: 32px;" type="submit" name="filtro_produ" value="Buscar">
                            </div>
                        </div>
                    </form>
                    <table id="table_id" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Imagen</th>
                                <th>SKU</th>
                                <th>Nombre</th>
                                <th>Categoria</th>
                                <th>Stock</th>
                                <th>Precio de venta</th>
                                <th>Fecha</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $parametros['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <?php if($val['state'] != "0"): ?>
                                    <td><img src="https://himart.com.mx/api/images/products/<?php echo e($val['id']); ?>/<?php echo e($val['id_image']); ?>" width="100" height="100" alt=""></td>
                                    <?php if($val['reference'] == []): ?>
                                        <td>Ref. vacío</td>
                                    <?php else: ?>
                                        <td><?php echo e($val['reference']); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($val['name']); ?></td>
                                    <td><?php echo e($val['category']); ?></td>
                                    <td><?php echo e($val['stock']); ?></td>
                      
                                    <td>$ <?php echo e(number_format($val['price'], 2)); ?></td>
                                    <td><?php echo e($val['date_upd']); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.productos.edit', $val['id'])); ?>" data-id="<?php echo e($val['id']); ?>" class="icon-pencil" data-toggle="tooltip" data-placement="top" data-original-title="Editar"> <i class="mdi mdi-pencil"></i></a>
                                        <a href="eliminar" data-id="<?php echo e($val['id']); ?>" class="icon-trash" data-toggle="tooltip" data-placement="top" data-original-title="Eliminar"> <i class="mdi mdi-delete"></i></a>
                                       
                                    </td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>

<?php echo $__env->make('auxiliares.design-datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>

<script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/inputmask/jquery.inputmask.min.js')); ?>"></script>

<?php echo $__env->make('auxiliares.scripts-datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erpjeramoda\resources\views/admin/productos/index.blade.php ENDPATH**/ ?>