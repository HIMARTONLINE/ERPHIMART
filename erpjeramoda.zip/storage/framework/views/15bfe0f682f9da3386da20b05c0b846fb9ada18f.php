<?php if(session('mensaje')): ?>
<div class="alert alert-info" role="alert">
	<?php echo e(session('mensaje')); ?>

	<button type="button" class="close" data-dismiss="alert" aria-label="close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php endif; ?> <?php /**PATH C:\laragon\www\erpjeramoda\resources\views/auxiliares/mensaje_exito.blade.php ENDPATH**/ ?>